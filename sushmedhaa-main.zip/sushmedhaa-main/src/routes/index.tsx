import { createFileRoute } from "@tanstack/react-router";
import { ArrowDown, ExternalLink, Mail, Phone, Linkedin, Download, FileText, Briefcase, GraduationCap, Cloud } from "lucide-react";
import cuteLady from "@/assets/cute-lady.png";
import cuteLadyAbout from "@/assets/cute-lady-about.png";
import { SiteHeader } from "@/components/SiteHeader";
import { SideRail } from "@/components/SideRail";
import { ResumeBlock, PortfolioRow, ResumeJob } from "@/components/ResumeParts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sushmedhaa — AWS Technical Lead & Systems Architect" },
      {
        name: "description",
        content:
          "AWS Technical Lead and Systems Architect engineering scalable, self-healing cloud-native systems. A decade of cloud transformation, data engineering, and DevOps excellence.",
      },
      { property: "og:title", content: "Sushmedhaa — AWS Technical Lead & Systems Architect" },
      {
        property: "og:description",
        content: "Cloud-native innovation, data intelligence, and DevOps excellence.",
      },
    ],
  }),
  component: Index,
});

const experience = [
  {
    role: "AWS Technical Lead (System Analyst)",
    company: "Hexaware Technologies · LSEG",
    period: "2023 — Present",
    tag: "current",
    bullets: [
      "Leading AWS-native architecture for high-frequency financial systems",
      "Achieved sub-second latency and 99.9% uptime across critical services",
      "Reduced incident resolution time by 35% through observability and runbooks",
      "Leading cross-functional teams and CI/CD standardization",
    ],
  },
  {
    role: "Cloud Engineer",
    company: "Tata Consultancy Services · BPost, Belgium",
    period: "2022 — 2023",
    bullets: [
      "Migrated legacy systems to AWS, gaining 40% in elasticity",
      "Built serverless ETL pipelines using AWS Glue & Lambda",
      "Reduced infrastructure costs by 25% through right-sizing & spot strategies",
      "Enabled real-time analytics via Redshift & Power BI",
    ],
  },
  {
    role: "System Engineer",
    company: "Tata Consultancy Services · Tata Communications",
    period: "2020 — 2022",
    bullets: [
      "Migrated Solaris environments to RHEL with zero downtime cutover",
      "Led Oracle database upgrades from 12c to 18c across critical estates",
    ],
  },
  {
    role: "Associate System Engineer",
    company: "Tata Consultancy Services · British Telecom",
    period: "2017 — 2020",
    bullets: [
      "Automated telecom billing processes using PL/SQL",
      "Eliminated manual handling of millions of records through automation",
    ],
  },
];

const skillTags = [
  "aws",
  "lambda",
  "redshift",
  "airflow",
  "python",
  "linux",
  "postgres",
  "oracle",
  "git",
  "power-bi",
];

const skillGroups = [
  {
    title: "// Cloud",
    items: ["EC2", "S3", "Lambda", "Glue", "Redshift", "Athena", "RDS", "IAM", "VPC", "CloudWatch", "CloudFormation"],
  },
  { title: "// Languages", items: ["Python", "SQL", "PL/SQL", "Shell", "Linux"] },
  { title: "// Data", items: ["ETL", "ELT", "Pipelines", "Warehousing", "Airflow", "AppWorx"] },
  { title: "// DevOps", items: ["Git", "Bitbucket", "SVN", "Jira", "Confluence", "Agile"] },
];

const projects = [
  {
    name: "LegacyShift",
    stack: "AWS · CloudFormation · Lambda · Terraform",
    desc: "Re-architected monolithic on-prem workloads into AWS-native, IaC-driven environments with zero-downtime cutover.",
    metric: "40% elasticity gain · 25% lower cost",
  },
  {
    name: "DataFlowX",
    stack: "AWS Glue · Lambda · Airflow · Redshift",
    desc: "Built event-driven serverless ETL pipelines materializing into Redshift for near real-time analytics.",
    metric: "Self-healing jobs · Unified warehouse",
  },
  {
    name: "MarketEdge",
    stack: "AWS · CloudWatch · CI/CD · Observability",
    desc: "Designed AWS-native architecture for high-frequency financial systems with deep observability and automated failover.",
    metric: "Sub-second latency · 99.9% uptime",
  },
];

function Index() {
  return (
    <div className="min-h-screen text-foreground">
      <SiteHeader />
      <SideRail />

      <main className="max-w-7xl mx-auto px-6 lg:px-20 pt-32">
        {/* HERO */}
        <section id="home" className="min-h-[80vh] grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
          <div className="space-y-8">
            <h1 className="font-mono text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
              Hi, I'm <span className="text-gradient">Sushmedhaa</span> — an{" "}
              <span className="text-gradient">AWS Technical Lead</span> and Systems Architect
            </h1>
            <p className="text-muted-foreground max-w-xl leading-relaxed">
              I'm engineering equilibrium through cloud-native innovation, data intelligence, and
              DevOps excellence — a decade of transforming legacy systems into scalable, self-healing
              AWS ecosystems.
            </p>
            <a
              href="#projects"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-colors text-sm font-mono"
            >
              Scroll Down <ArrowDown className="size-4" />
            </a>
          </div>

          <div className="relative">
            {/* decorative frames */}
            <div className="absolute -top-6 -left-6 w-24 h-24 border border-primary/40" />
            <div className="absolute -top-2 -left-2 w-16 h-16 border border-primary/30" />
            <div className="absolute -bottom-8 -right-8 w-32 h-32 dotted-grid opacity-60" />

            <div
              className="relative rounded-2xl overflow-hidden border border-border p-8 flex items-center justify-center"
              style={{
                background:
                  "radial-gradient(circle at 50% 30%, color-mix(in oklab, var(--primary) 25%, transparent), var(--surface))",
                boxShadow: "var(--shadow-card)",
              }}
            >
              <img
                src={cuteLady}
                alt="Cute illustrated portrait of Sushmedhaa, AWS Technical Lead"
                width={896}
                height={1152}
                className="w-full max-w-sm h-auto drop-shadow-2xl"
              />
            </div>

            <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-md border border-border bg-surface/60 backdrop-blur text-sm">
              <span className="size-2 bg-primary rounded-sm animate-pulse" />
              Currently leading at <span className="text-primary font-bold">LSEG</span>
            </div>
          </div>
        </section>

        {/* QUOTE */}
        <section className="my-24">
          <figure className="surface-card p-8 md:p-12 max-w-3xl mx-auto relative">
            <span className="absolute -top-6 left-6 text-6xl text-primary font-serif leading-none">
              "
            </span>
            <blockquote className="text-lg md:text-xl text-foreground/90 leading-relaxed">
              The best architecture is the one you don't notice. <br />
              Quiet systems that absorb chaos and let teams build.
            </blockquote>
            <figcaption className="text-right text-muted-foreground text-sm mt-4">
              — Sushmedhaa
            </figcaption>
            <span className="absolute -bottom-2 right-6 text-6xl text-primary font-serif leading-none">
              "
            </span>
          </figure>
        </section>

        {/* ABOUT */}
        <section id="about-me" className="py-20 grid lg:grid-cols-[1fr_1.4fr] gap-12 items-center">
          <div className="relative order-2 lg:order-1">
            <div
              className="rounded-2xl overflow-hidden border border-border p-6"
              style={{
                background:
                  "linear-gradient(160deg, color-mix(in oklab, var(--primary) 18%, var(--surface)), var(--surface-2))",
              }}
            >
              <img
                src={cuteLadyAbout}
                alt="Cute cartoon of Sushmedhaa coding with cloud icons"
                width={1024}
                height={1152}
                loading="lazy"
                className="w-full h-auto"
              />
            </div>
            <div className="grid grid-cols-3 gap-3 mt-6">
              <Stat n="10+" label="years" />
              <Stat n="4" label="clients" />
              <Stat n="99.9%" label="uptime" />
            </div>
          </div>

          <div className="order-1 lg:order-2 space-y-6">
            <SectionHeading id="about-me" label="about-me" />
            <h3 className="text-3xl font-display font-bold">Hello, I'm Sushmedhaa!</h3>
            <p className="text-muted-foreground leading-relaxed">
              I'm a seasoned cloud architect based in Chennai, India. I transform legacy systems
              into scalable, self-healing AWS ecosystems and bridge the gap between data
              engineering and DevOps for global enterprises.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              I am an Information Technology graduate from Pondicherry University with a decade of
              experience leading cloud migrations, building serverless data pipelines, and
              architecting high-performance financial systems. I'm passionate about resilient
              design, observability, and quiet systems that just work.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="#resume"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-primary text-primary-foreground hover:bg-primary-glow transition-colors text-sm font-mono font-bold"
              >
                View Resume <ExternalLink className="size-4" />
              </a>
              <a
                href="/Sushmedhaa_Resume.pdf"
                download
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border hover:border-primary hover:text-primary transition-colors text-sm font-mono"
              >
                Download PDF <Download className="size-4" />
              </a>
            </div>
          </div>
        </section>

        {/* EDUCATION */}
        <section className="py-20">
          <SectionHeading label="education" />
          <div className="grid md:grid-cols-3 gap-6 mt-10">
            <EduCard
              when="// Bachelor's Degree"
              title="B.E. in Information Technology"
              org="Pondicherry University"
              meta="CGPA: 8.92"
            />
            <EduCard
              when="// 2010 — 2012"
              title="Higher Secondary Education"
              org="HSC · Class XII"
              meta="Score: 69%"
            />
            <EduCard
              when="// Up to 2010"
              title="Secondary School (SSLC)"
              org="Class X"
              meta="Score: 67%"
            />
          </div>
        </section>

        {/* EXPERIENCE */}
        <section className="py-20">
          <SectionHeading label="experience" />
          <div className="mt-10 space-y-6">
            {experience.map((e) => (
              <article
                key={e.role}
                className="surface-card p-6 md:p-8 hover:border-primary/60 transition-colors group"
              >
                <div className="flex flex-wrap items-baseline justify-between gap-3 mb-2">
                  <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                    {e.role}
                  </h3>
                  {e.tag && (
                    <span className="text-xs px-2 py-1 rounded bg-primary/15 text-primary border border-primary/30">
                      {e.tag}
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-1">{e.company}</p>
                <p className="text-xs text-primary mb-4 font-mono">{e.period}</p>
                <ul className="space-y-2">
                  {e.bullets.map((b) => (
                    <li
                      key={b}
                      className="text-sm text-muted-foreground flex gap-2 leading-relaxed"
                    >
                      <span className="text-primary shrink-0">&gt;</span>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>

        {/* SKILLS */}
        <section id="skills" className="py-20">
          <SectionHeading label="skills" />
          <div className="flex flex-wrap gap-3 mt-10">
            {skillTags.map((s) => (
              <span
                key={s}
                className="px-3 py-1.5 text-sm rounded-md border border-border bg-surface/60 text-muted-foreground hover:border-primary hover:text-primary transition-colors font-mono"
              >
                {s}
              </span>
            ))}
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-10">
            {skillGroups.map((g) => (
              <div key={g.title} className="surface-card p-6">
                <h3 className="text-primary font-mono mb-4">{g.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {g.items.map((i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 text-xs rounded bg-surface-2 text-foreground/80 border border-border"
                    >
                      {i}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className="py-20">
          <div className="flex items-end justify-between flex-wrap gap-4">
            <SectionHeading label="projects" />
            <a href="#contact-me" className="text-sm text-primary hover:text-primary-glow">
              View all →
            </a>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mt-10">
            {projects.map((p) => (
              <article
                key={p.name}
                className="surface-card p-6 group hover:border-primary/60 hover:-translate-y-1 transition-all"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs text-muted-foreground font-mono">{p.name}</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-primary/15 text-primary border border-primary/30">
                    Live
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                  {p.name}
                </h3>
                <p className="text-xs text-primary mb-3 font-mono">{p.stack}</p>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">{p.desc}</p>
                <p className="text-xs text-foreground/70 border-t border-border pt-3 font-mono">
                  {p.metric}
                </p>
              </article>
            ))}
          </div>
        </section>

        {/* RESUME */}
        <section id="resume" className="py-20">
          <div className="flex items-end justify-between flex-wrap gap-4">
            <SectionHeading label="resume" />
            <a
              href="/Sushmedhaa_Resume.pdf"
              download
              className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary-glow transition-colors text-sm font-mono font-bold"
            >
              <Download className="size-4" /> Download PDF
            </a>
          </div>

          <div className="mt-10 surface-card p-8 md:p-12" style={{ boxShadow: "var(--shadow-card)" }}>
            <div className="flex flex-wrap items-start justify-between gap-6 pb-6 border-b border-border">
              <div>
                <h3 className="text-3xl md:text-4xl font-display font-bold tracking-tight">
                  SUSHMEDHAA S
                </h3>
                <p className="text-primary font-mono mt-2 text-sm">
                  AWS Technical Lead · Data Engineer
                </p>
              </div>
              <ul className="text-sm text-muted-foreground space-y-1 font-mono">
                <li>Chennai, TN</li>
                <li>+91 90038 29744</li>
                <li>sushmedhaasp@gmail.com</li>
                <li>linkedin.com/in/sushmedhaa</li>
              </ul>
            </div>

            <ResumeBlock icon={<FileText className="size-5" />} title="Executive Summary">
              <p className="text-muted-foreground leading-relaxed">
                <span className="text-foreground font-bold">AWS Technical Lead</span> with over 8
                years of experience in high-scale Cloud Engineering and Data Architecture. Expert
                in architecting distributed, cloud-native systems and leading large-scale
                migrations for global BFSI and Telecom enterprises. Proven record in achieving{" "}
                <span className="text-primary font-bold">99.9% availability</span> and driving
                technical excellence through team mentorship and automated CI/CD workflows.
              </p>
            </ResumeBlock>

            <ResumeBlock icon={<Cloud className="size-5" />} title="Technical Portfolio">
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <PortfolioRow
                  label="Cloud"
                  value="AWS (EC2, S3, Lambda, Glue, Redshift, Athena, RDS, IAM, VPC, CloudWatch, CloudFormation)"
                />
                <PortfolioRow
                  label="Data Ops"
                  value="ETL/ELT Pipelines, Data Warehousing, Data Modeling, Apache Airflow"
                />
                <PortfolioRow
                  label="Languages"
                  value="Python (Expert-level DSA), SQL, PL/SQL, Shell Scripting, Linux"
                />
                <PortfolioRow
                  label="DevOps / BI"
                  value="Git, Bitbucket, CI/CD Pipelines, Power BI (DAX), JIRA"
                />
              </div>
            </ResumeBlock>

            <ResumeBlock icon={<Briefcase className="size-5" />} title="Professional Experience">
              <div className="space-y-6">
                <ResumeJob
                  role="AWS Technical Lead (System Analyst)"
                  period="2023 – Present"
                  company="Hexaware Technologies"
                  client="London Stock Exchange Group (LSEG)"
                  bullets={[
                    ["Architectural Modernization", "Spearheading the transition to AWS-native architectures for high-frequency financial platforms, ensuring sub-second latency and 99.9% uptime for global stock exchange services."],
                    ["Performance Engineering", "Directing L3 production support and root-cause analysis (RCA); reduced incident resolution time by 35% through query optimization and advanced database indexing."],
                    ["Team Leadership", "Managing a cross-functional engineering team, standardizing deployment via automated CI/CD pipelines, and establishing high-fidelity coding standards."],
                  ]}
                />
                <ResumeJob
                  role="Cloud Engineer"
                  period="2022 – 2023"
                  company="Tata Consultancy Services (TCS)"
                  client="BPost, Belgium"
                  bullets={[
                    ["Enterprise Migration", "Orchestrated the migration of legacy workloads to AWS, resulting in a 40% gain in resource elasticity and a 25% reduction in annual infrastructure overhead."],
                    ["Serverless Automation", "Architected end-to-end serverless ETL data pipelines using AWS Glue and Lambda; automated 100% of infrastructure provisioning via CloudFormation."],
                    ["Modern Analytics", "Transitioned legacy Oracle reporting to Redshift and Power BI, enabling real-time operational insights for a global logistics network."],
                  ]}
                />
                <ResumeJob
                  role="System Engineer"
                  period="2020 – 2022"
                  company="Tata Consultancy Services (TCS)"
                  client="Tata Communications"
                  bullets={[
                    ["System Modernization", "Directed the high-risk migration of business-critical production servers from Solaris to RHEL, modernizing the OS environment for enhanced security."],
                    ["Database Migration", "Managed Oracle 12c to 18c migration cycles, significantly improving data processing speeds for mission-critical downstream services."],
                  ]}
                />
                <ResumeJob
                  role="Associate System Engineer"
                  period="2017 – 2020"
                  company="Tata Consultancy Services (TCS)"
                  client="British Telecom"
                  bullets={[
                    ["Automation Engineering", "Developed complex PL/SQL scripts for telecom billing mediation, eliminating manual processing for millions of daily records."],
                  ]}
                />
              </div>
            </ResumeBlock>

            <ResumeBlock icon={<GraduationCap className="size-5" />} title="Academic Excellence">
              <div>
                <h4 className="font-bold text-foreground">
                  Bachelor of Engineering in Information Technology
                </h4>
                <p className="text-muted-foreground text-sm mt-1">Pondicherry University</p>
                <p className="text-primary text-sm mt-1 font-mono">
                  Distinction Grade · CGPA: 8.92
                </p>
              </div>
            </ResumeBlock>
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact-me" className="py-20">
          <SectionHeading label="contacts" />
          <div className="grid lg:grid-cols-2 gap-12 mt-10 items-start">
            <p className="text-muted-foreground leading-relaxed text-lg">
              I'm interested in leadership roles, advisory work, and conversations about cloud
              transformation. However, if you have other requests or questions, don't hesitate to
              contact me.
            </p>
            <div className="surface-card p-8" style={{ boxShadow: "var(--shadow-card)" }}>
              <h3 className="text-xl font-bold mb-6">Message me here</h3>
              <ul className="space-y-4">
                <ContactRow
                  icon={<Linkedin className="size-4" />}
                  href="https://linkedin.com/in/sushmedhaa"
                  label="sushmedhaa"
                />
                <ContactRow
                  icon={<Mail className="size-4" />}
                  href="mailto:sushmedhaasp@gmail.com"
                  label="sushmedhaasp@gmail.com"
                />
                <ContactRow
                  icon={<Phone className="size-4" />}
                  href="tel:+919003829744"
                  label="+91 9003829744"
                />
              </ul>
            </div>
          </div>
        </section>

        <footer className="py-10 text-center text-xs text-muted-foreground border-t border-border mt-10">
          <p>© {new Date().getFullYear()} Sushmedhaa Subramaniyan · Built with care</p>
        </footer>
      </main>
    </div>
  );
}

function SectionHeading({ label, id }: { label: string; id?: string }) {
  return (
    <h2 id={id} className="text-2xl md:text-3xl font-display font-bold flex items-center gap-3">
      <span className="text-primary">##</span>
      <span>{label}</span>
      <span className="flex-1 h-px bg-border ml-4" />
    </h2>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div className="surface-card p-4 text-center">
      <div className="text-2xl font-bold text-gradient">{n}</div>
      <div className="text-xs text-muted-foreground mt-1 font-mono">{label}</div>
    </div>
  );
}

function EduCard({
  when,
  title,
  org,
  meta,
}: {
  when: string;
  title: string;
  org: string;
  meta: string;
}) {
  return (
    <div className="surface-card p-6 hover:border-primary/60 transition-colors">
      <p className="text-xs text-primary font-mono mb-3">{when}</p>
      <h3 className="text-lg font-bold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{org}</p>
      <p className="text-sm text-foreground/70 mt-2 font-mono">{meta}</p>
    </div>
  );
}

function ContactRow({
  icon,
  href,
  label,
}: {
  icon: React.ReactNode;
  href: string;
  label: string;
}) {
  return (
    <li>
      <a
        href={href}
        className="flex items-center gap-3 text-foreground/90 hover:text-primary transition-colors group"
      >
        <span className="size-8 grid place-items-center rounded-md border border-border group-hover:border-primary group-hover:bg-primary/10">
          {icon}
        </span>
        <span className="text-sm">{label}</span>
      </a>
    </li>
  );
}



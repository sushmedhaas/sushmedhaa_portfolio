import type { ReactNode } from "react";

export function ResumeBlock({
  icon,
  title,
  children,
}: {
  icon: ReactNode;
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="mt-8">
      <h4 className="flex items-center gap-2 text-primary font-mono text-sm uppercase tracking-widest mb-4">
        <span className="text-primary">{icon}</span>
        {title}
      </h4>
      <div>{children}</div>
    </div>
  );
}

export function PortfolioRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-l-2 border-primary/40 pl-3">
      <p className="text-xs text-primary font-mono uppercase tracking-wider mb-1">{label}</p>
      <p className="text-foreground/80 text-sm leading-relaxed">{value}</p>
    </div>
  );
}

export function ResumeJob({
  role,
  period,
  company,
  client,
  bullets,
}: {
  role: string;
  period: string;
  company: string;
  client: string;
  bullets: [string, string][];
}) {
  return (
    <article className="border-l-2 border-border hover:border-primary transition-colors pl-5 py-1">
      <div className="flex flex-wrap items-baseline justify-between gap-2 mb-1">
        <h5 className="font-bold text-foreground">{role}</h5>
        <span className="text-xs text-primary font-mono">{period}</span>
      </div>
      <p className="text-sm text-muted-foreground italic mb-3">
        {company} <span className="text-foreground/60">| Client: {client}</span>
      </p>
      <ul className="space-y-2">
        {bullets.map(([k, v]) => (
          <li key={k} className="text-sm text-muted-foreground leading-relaxed">
            <span className="text-foreground font-bold">{k}:</span> {v}
          </li>
        ))}
      </ul>
    </article>
  );
}

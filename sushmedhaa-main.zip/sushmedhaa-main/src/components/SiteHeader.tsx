import { useEffect, useState } from "react";

const links = [
  { hash: "#home", label: "home" },
  { hash: "#projects", label: "projects" },
  { hash: "#skills", label: "skills" },
  { hash: "#about-me", label: "about-me" },
  { hash: "#resume", label: "resume" },
  { hash: "#contact-me", label: "contact-me" },
];

export function SiteHeader() {
  const [active, setActive] = useState("#home");

  useEffect(() => {
    const sections = links
      .map((l) => document.getElementById(l.hash.slice(1)))
      .filter((el): el is HTMLElement => !!el);

    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(`#${e.target.id}`);
        });
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    sections.forEach((s) => obs.observe(s));
    return () => obs.disconnect();
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-background/70 border-b border-border">
      <nav className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-2 font-bold text-foreground">
          <span className="text-primary">&lt;/&gt;</span>
          <span>Sushmedhaa</span>
        </a>
        <ul className="hidden md:flex items-center gap-6 text-sm">
          {links.map((l) => (
            <li key={l.hash}>
              <a href={l.hash} className="hash-link" data-active={active === l.hash}>
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}

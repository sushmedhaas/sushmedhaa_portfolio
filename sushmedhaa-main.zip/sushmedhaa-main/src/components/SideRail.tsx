import { Github, Linkedin, Mail } from "lucide-react";

export function SideRail() {
  return (
    <aside className="hidden lg:flex fixed left-6 bottom-0 top-1/2 -translate-y-1/2 flex-col items-center gap-6 z-40">
      <a
        href="https://github.com/"
        aria-label="GitHub"
        className="text-muted-foreground hover:text-primary transition-colors"
      >
        <Github className="size-5" />
      </a>
      <a
        href="https://linkedin.com/in/sushmedhaa"
        aria-label="LinkedIn"
        className="text-muted-foreground hover:text-primary transition-colors"
      >
        <Linkedin className="size-5" />
      </a>
      <a
        href="mailto:sushmedhaasp@gmail.com"
        aria-label="Email"
        className="text-muted-foreground hover:text-primary transition-colors"
      >
        <Mail className="size-5" />
      </a>
      <div className="w-px h-32 bg-border" />
    </aside>
  );
}
